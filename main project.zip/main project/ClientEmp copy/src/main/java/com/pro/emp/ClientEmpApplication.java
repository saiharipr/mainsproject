package com.pro.emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientEmpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientEmpApplication.class, args);
	}

}
