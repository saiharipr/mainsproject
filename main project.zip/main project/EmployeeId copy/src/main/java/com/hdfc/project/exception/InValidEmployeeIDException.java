package com.hdfc.project.exception;

public class InValidEmployeeIDException extends Exception {

	public InValidEmployeeIDException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

}
