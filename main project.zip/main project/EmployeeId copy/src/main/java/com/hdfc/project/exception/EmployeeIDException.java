package com.hdfc.project.exception;

public class EmployeeIDException extends Exception{
	
	public EmployeeIDException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}
}
